<?php
// Path to the quotes.json file
$dataFile = __DIR__ . '/data/quotes.json';

// Ensure the data folder and file exist
if (!file_exists($dataFile)) {
    if (!is_dir(dirname($dataFile))) {
        mkdir(dirname($dataFile), 0777, true);
    }
    file_put_contents($dataFile, json_encode([])); // Initialize with an empty array
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quote = $_POST['quote'] ?? '';
    $author = $_POST['author'] ?? '';
    $timestamp = date('Y-m-d H:i:s');

    // Validate inputs
    if (trim($quote) !== '' && trim($author) !== '') {
        $newEntry = [
            'quote' => htmlspecialchars($quote),
            'author' => htmlspecialchars($author),
            'timestamp' => $timestamp,
        ];

        // Read existing quotes and append new one
        $quotes = json_decode(file_get_contents($dataFile), true);
        $quotes[] = $newEntry;

        // Save back to the file
        file_put_contents($dataFile, json_encode($quotes, JSON_PRETTY_PRINT));
    }
}

// Load existing quotes
$quotes = json_decode(file_get_contents($dataFile), true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>The Quotebook</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <script src="js/jquery-3.7.1.min.js"></script>
    <script src="js/main.js"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-C8THLPL8DP"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        
        gtag('config', 'G-C8THLPL8DP');
        </script>
<script>

</script>
</head>

<body>
    <h1>Submit a Quote</h1>
    <form method="POST">
        <textarea name="quote" placeholder="Enter the quote" required></textarea>
        <input type="text" name="author" placeholder="Who said it?" required />
        <button type="submit">Submit Quote</button>
    </form>

    <div class="quote-list">
        <h2>Submitted Quotes</h2>
        <?php foreach ($quotes as $entry): ?>
            <div class="quote">
                <p>"<?php echo $entry['quote']; ?>"</p>
                <div class="author">- <?php echo $entry['author']; ?></div>
                <div class="timestamp"><?php echo $entry['timestamp']; ?></div>
                <br>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Navigation -->
    <nav id="main-nav" class="sticky top-0 nav-blur border-b border-gray-200 z-50 hidden">
        <div class="max-w-6xl mx-auto px-4">
            <div class="flex items-center justify-between h-16">
                <div class="font-serif font-bold text-xl text-gray-800">
                    The Quotebook
                </div>
                
                <!-- Hamburger Button (mobile only) -->
                <button id="hamburger-btn" class="p-2 rounded-md text-gray-500 hover:text-gray-600 focus:outline-none md:hidden">
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>

                <!-- Desktop Navigation -->
                <div class="desktop-nav">
                    <button data-tab="home" class="nav-item active">
                        <svg class="nav-icon" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l9-9 9 9M5 10v10a1 1 0 001 1h3m10-11l-9-9-9 9M9 21h6m-6 0H4m16 0h-3"/>
                        </svg>
                        <span>Home</span>
                    </button>
                    <button data-tab="profile" class="nav-item">
                        <svg class="nav-icon" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                        </svg>
                        <span>Profile</span>
                    </button>
                    <button data-tab="about" class="nav-item">
                        <svg class="nav-icon" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        <span>About</span>
                    </button>
                    <button id="logout-btn" class="nav-item">
                        <svg class="nav-icon" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                        </svg>
                        <span>Logout</span>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="mobile-menu">
        <div class="flex justify-between items-center mb-6 p-4 border-b">
            <span class="font-serif font-bold text-xl">Menu</span>
            <button id="close-menu" class="p-2">
                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>
        <div class="space-y-1">
            <button data-tab="home" class="mobile-nav-item">Home</button>
            <button data-tab="profile" class="mobile-nav-item">Profile</button>
            <button data-tab="about" class="mobile-nav-item">About</button>
            <button id="mobile-logout-btn" class="mobile-nav-item">Logout</button>
        </div>
    </div>

    <!-- Main Content -->
    <main class="flex-grow p-4">
        <div class="max-w-2xl mx-auto">
            <!-- Auth Section -->
            <div id="auth-section" class="content-section">
                <div id="auth-content"></div>
            </div>

            <!-- Home Section -->
            <div id="home-section" class="content-section hidden"></div>

            <!-- Profile Section -->
            <div id="profile-section" class="content-section hidden"></div>

            <!-- About Section -->
            <div id="about-section" class="content-section hidden">
                <div class="content-card">
                    <h2 class="text-2xl font-serif font-bold text-gray-800 mb-4">Where it all started...</h2>
                    <p class="text-gray-600 font-serif leading-relaxed mb-4">
                        Between being raised in a city like New York, and having a big fat Lebanese-Venezuelan family, Lola has never had a shortage of overhearing the wildest things on a day-to-day basis. 
                    </p>
                    <p class="text-gray-600 font-serif leading-relaxed mb-8">
                        Having realized the extra-ordinary nature of the characters (both known and strangers) in her life, she decided these magically overheard treasures could not go undocumented. And thus, was born the quote book. After 5 years…this is her best party trick and easiest sell. Countless of her friends have started their own and often find themselves w their notes out reading them to each other, laughing hysterically.  After all the joy “the quotebook” (as she calls it) has brought her and the people in her life…she realized it was time for her and her friends to help everyone start their own Quotebooks…
<p>SO WELCOME AND HAPPY QUOTING.</p>
                    </p>
                    <div class="video-container">
                        <iframe 
                            src="https://www.youtube.com/embed/0wQLflDq-yU" 
                            title="The Power of Words"
                            frameborder="0" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                            allowfullscreen>
                        </iframe>
                    </div>
                </div>
            </div>
        
</body>
</html>
